const express = require("express");
const mongoose = require("mongoose");
const helmet = require("helmet");
const path = require("path");

const app = express();

// Middleware
app.use(helmet()); // Adds security headers
app.use(express.json());

// Cache busting for static files
app.use('/static', express.static(path.join(__dirname, 'public'), {
  setHeaders: (res) => {
    res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
    res.setHeader("Expires", "0");
  }
}));

// Middleware to enforce charset=utf-8
app.use((req, res, next) => {
  res.setHeader("Content-Type", "application/javascript; charset=utf-8");
  next();
});

// MongoDB Connection
mongoose
  .connect('mongodb+srv://chinmay:chinmay@mini.pr15x.mongodb.net/?retryWrites=true&w=majority&appName=mini', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => console.log("MongoDB connected"))
  .catch((err) => console.error(err));

// Routes
app.get("/", (req, res) => {
  res.send("Welcome to the Real Estate API");
});

// Start server
const PORT = 5000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
